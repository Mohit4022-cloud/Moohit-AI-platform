# Project Guidelines for Claude

## Important Instructions

### Internal vs External Pages
- **NEVER** modify external/public pages when working on internal pages
- Internal pages are dashboard-related pages (e.g., /dashboard, /leads, /queue, etc.)
- External pages are public-facing pages (e.g., /, /about, /pricing, /features, etc.)
- When making changes to internal pages, ensure CSS and JavaScript changes are scoped to only affect internal pages
- Use specific selectors and avoid global styles that could affect external pages

### Current Project Context
- Working on V7.1 branch
- Focus on fixing internal dashboard functionality
- Sidebar navigation should show both icons and text labels on desktop